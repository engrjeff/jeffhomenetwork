let App = {};


App.UiManager = function () {
    let module = {};
    module.tabs = null;
    module.sections = null;

    module.init = function () {
        module.getElements();
        module.setEvents();
    };
    module.getElements = function () {
        module.tabs = document.querySelectorAll(".app-tab");
        module.sections = document.querySelectorAll(".app-section");
    };
    module.setEvents = function () {
        [].forEach.call(module.tabs, function (t) {
            t.onclick = function () { module.switchPage(t); };
        });
    };
    module.removeActiveTabClass = function () {
        [].forEach.call(module.tabs, function (t) {
            t.classList.remove("active");
        });
    };
    module.goToPage = function (section) {
        [].forEach.call(module.sections, function (s) {
            if (s.getAttribute("section") === section) {
                s.classList.remove("display-none");
            } else {
                s.classList.add("display-none");
            }
        })
    };
    module.switchPage = function (tab) {
        module.removeActiveTabClass();
        tab.classList.add("active");
        let section = tab.getAttribute("section");
        module.goToPage(section);
    };
    return module;
}();

App.Renderer = function () {
    let render = {};

    render.tempCanvas = null;
    render.humCanvas = null;
    render.phCanvas = null;

    render.tempChart = null;
    render.humChart = null;
    render.phChart = null;


    render.tempColor = "rgb(17, 156, 254)";
    render.tempColorA = "rgba(17, 156, 254, 0.3)";

    render.humColor = "rgb(255, 100, 132)";
    render.humColorA = "rgba(255, 100, 132, 0.3)";

    render.phColor = "rgb(9, 172, 151)";

    render.init = function () {
        render.getCanvas();
        render.plotCharts();
    };

    render.getCanvas = function () {
        render.tempCanvas = document.querySelector("#tempChart");
        render.humCanvas = document.querySelector("#humChart");
        render.phCanvas = document.querySelector("#phChart");
    };
    render.plotCharts = function () {
        render.plotTemp();
        render.plotHum();
        render.plotPh();
    };

    render.chart = function (canvas, type, labels, datasets) {
        let ctx = canvas.getContext("2d");
        let props = {
            type: type,
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    // yAxes: [{
                    //     gridLines: {
                    //         color: "rgba(0, 0, 0, 0)",
                    //     }
                    // }],
                }
            },
        };
        let chart = new Chart(ctx, props);
        return chart;
    };

    render.plotTemp = function () {
        let data = [];

        for (let i = 0; i < 25; i++) {
            let t = (Math.random() * 25 + 10).toFixed(2);
            data.push(parseFloat(t));
        }

        let labels = ["1", "2", "3", "4", "5"];
        let datasets = [{
            label: "Temperature",
            data: data,
            backgroundColor: render.tempColorA,
            borderColor: render.tempColor,
            fill: true,
        }]
        render.tempChart = render.chart(render.tempCanvas, "line", labels, datasets);
    };
    render.plotHum = function () {
        let data = [];

        for (let i = 0; i < 25; i++) {
            let t = (Math.random() * 25 + 10).toFixed(2);
            data.push(parseFloat(t));
        }

        let labels = ["1", "2", "3", "4", "5"];
        let datasets = [{
            label: "Humidity",
            data: data,
            backgroundColor: render.humColorA,
            borderColor: render.humColor,
            fill: true,
        }]
        render.humChart = render.chart(render.humCanvas, "line", labels, datasets);
    };
    render.plotPh = function () {
        let ctx = render.phCanvas.getContext("2d");
        let props = {
            type: "doughnut",
            data: {
                datasets: [{
                    data: [
                        7.4, 6.6
                    ],
                    backgroundColor: [
                        render.phColor,
                        "#ccc",
                    ],
                    label: 'pH Level',
                }],
                labels: [
                    'Current Value',
                ]

            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                circumference: Math.PI,
                rotation: -Math.PI,
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'pH Level'
                },
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            },
        };
        let chart = new Chart(ctx, props);
    };
    return render;
}();




function init() {
    App.UiManager.init();
    App.Renderer.init();
}

window.onload = function () {
    init();
}